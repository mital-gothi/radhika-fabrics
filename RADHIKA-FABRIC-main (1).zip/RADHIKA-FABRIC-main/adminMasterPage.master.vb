﻿
Partial Class Admin_adminMasterPage
    Inherits System.Web.UI.MasterPage
End Class

